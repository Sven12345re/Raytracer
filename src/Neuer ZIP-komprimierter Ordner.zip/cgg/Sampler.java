package cgg;

import cgtools.Color;

public interface Sampler {
     Color getColor(double x, double y);
}
