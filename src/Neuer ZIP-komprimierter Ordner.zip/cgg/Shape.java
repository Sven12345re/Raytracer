package cgg;

public interface Shape {

    Hit intersectWith(Ray ray);
}
