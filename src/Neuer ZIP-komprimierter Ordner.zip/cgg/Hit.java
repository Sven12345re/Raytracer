package cgg;

import cgtools.Color;
import cgtools.Point;
import cgtools.Vector;

import java.util.Comparator;

public class Hit implements Comparable<Hit> {
    double t;
    Point x;
    Vector n;
    Material material;

    public Hit(double t, Point x, Vector n, Material material) {
        this.t = t;
        this.x = x;
        this.n = n;
        this.material = material;
    }

    public double getT() {
        return t;
    }

    public Point getX() {
        return x;
    }

    public Vector getN() {
        return n;
    }



    @Override
    public int compareTo(Hit o) {

        if (this.t < o.t) {
            return -1;
        }else if (this.t > o.t) {
            return 1;
        }else {
            return 0;
        }
    }



}