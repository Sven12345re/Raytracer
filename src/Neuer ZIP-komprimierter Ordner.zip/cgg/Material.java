package cgg;

import cgtools.*;

public interface Material {

    Color emmision(Ray r, Hit H);
    Color albedo(Ray r, Hit h);
    Direction reflectedRay(Ray r, Hit h);
}
